var menu_8hpp =
[
    [ "Menu", "class_menu.html", "class_menu" ],
    [ "MAX_TEMP_ROW", "menu_8hpp.html#a6d602e9dfae9461c3a74d5e68f28c5df", null ]
];