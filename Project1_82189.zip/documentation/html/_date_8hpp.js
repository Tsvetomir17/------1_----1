var _date_8hpp =
[
    [ "Date", "class_date.html", "class_date" ],
    [ "TIME_LENGHT", "_date_8hpp.html#a914c58d16db93b45e3da98a4cf013114", null ]
];