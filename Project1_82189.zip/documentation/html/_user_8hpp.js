var _user_8hpp =
[
    [ "User", "class_user.html", "class_user" ],
    [ "MAX_LENGTH", "_user_8hpp.html#a9078d077f94a0e8f71ec446abe515d4f", null ],
    [ "MAX_TEMP_ROW", "_user_8hpp.html#a1fe69913d6fa660083f4fd9dfc325cf9", null ]
];