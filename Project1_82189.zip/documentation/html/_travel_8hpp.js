var _travel_8hpp =
[
    [ "Travel", "class_travel.html", "class_travel" ],
    [ "MAX_LENGTH_TRAVEL", "_travel_8hpp.html#a5cfe1e31ceb55e2e612ba4f27334dd11", null ],
    [ "MAX_LENGTH_TRAVEL2", "_travel_8hpp.html#aa510f1147c2ff103c003cde045852e83", null ]
];