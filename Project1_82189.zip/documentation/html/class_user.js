var class_user =
[
    [ "User", "class_user.html#a4a0137053e591fbb79d9057dd7d2283d", null ],
    [ "User", "class_user.html#aad23b10cdefd26d6ca2ca981e9f9c973", null ],
    [ "~User", "class_user.html#ac00b72ad64eb4149f7b21b9f5468c2b2", null ],
    [ "checkIfEmailAdressIsCorrect", "class_user.html#a6a892a2d520ba48c2b43bc57d359a46c", null ],
    [ "checkIfUsernameIsCorrect", "class_user.html#abe7cebcc4f32375cb5b7efe2106690c0", null ],
    [ "copy", "class_user.html#aee3e12a73807a68982aba3fcf7021498", null ],
    [ "deallocate", "class_user.html#ac9e434f6731c5a8664e75f40d0ce19db", null ],
    [ "operator=", "class_user.html#a00fe82353b0ee8cf6abb1088d36e125b", null ],
    [ "operator<<", "class_user.html#a4b94d005cfaf22d1536ee0b653a2b44b", null ],
    [ "operator>>", "class_user.html#a24f81f911c6acaee5721f6e0d49f527f", null ],
    [ "emailAdress", "class_user.html#a7ad7e9863f35b6214762b65c810c0bda", null ],
    [ "password", "class_user.html#aae9d564fe8553342510c0b7b79edb360", null ],
    [ "username", "class_user.html#aa5a1a545c2690cf801b6624596ce6cf4", null ]
];