var _date_8cpp =
[
    [ "operator<<", "_date_8cpp.html#ada4f8712609249fde898198589dc73e5", null ],
    [ "operator>>", "_date_8cpp.html#a4d60fae6ffff4d027e1e987183c4cdbc", null ]
];