var searchData=
[
  ['date_0',['Date',['../class_date.html#a4e59ed4ba66eec61c27460c5d09fa1bd',1,'Date']]],
  ['deallocate_1',['deallocate',['../class_travel.html#a05cbe75d3d60e28d4b95ffdd5a94d3b7',1,'Travel::deallocate()'],['../class_user.html#ac9e434f6731c5a8664e75f40d0ce19db',1,'User::deallocate()']]]
];
