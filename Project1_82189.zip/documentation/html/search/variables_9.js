var searchData=
[
  ['username_0',['username',['../class_menu.html#acce4ed016501b2869706776e4f794b0b',1,'Menu::username()'],['../class_user.html#aa5a1a545c2690cf801b6624596ce6cf4',1,'User::username()']]]
];
