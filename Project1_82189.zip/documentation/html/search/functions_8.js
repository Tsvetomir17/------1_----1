var searchData=
[
  ['user_0',['User',['../class_user.html#a4a0137053e591fbb79d9057dd7d2283d',1,'User::User()'],['../class_user.html#aad23b10cdefd26d6ca2ca981e9f9c973',1,'User::User(const User &amp;other)']]]
];
