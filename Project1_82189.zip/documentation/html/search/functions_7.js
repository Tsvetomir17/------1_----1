var searchData=
[
  ['travel_0',['Travel',['../class_travel.html#acc3bc73b916e588699d18ba7d4bb25c2',1,'Travel::Travel()'],['../class_travel.html#a3e9aed48a34eb599a80eab350c9813ca',1,'Travel::Travel(const Travel &amp;other)']]]
];
