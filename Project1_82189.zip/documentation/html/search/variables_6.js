var searchData=
[
  ['max_5flength_0',['MAX_LENGTH',['../class_user.html#a5088d03f5e35e67c0a6a4ada62b6c2d7',1,'User']]],
  ['max_5flength_5ftravel_1',['MAX_LENGTH_TRAVEL',['../class_travel.html#acc3b957622dcffd3fe08667d58c098d5',1,'Travel']]],
  ['max_5flength_5ftravel2_2',['MAX_LENGTH_TRAVEL2',['../class_travel.html#accae6a70d1e79f0363e85ab47f2bb22c',1,'Travel']]],
  ['max_5ftemp_5frow_3',['MAX_TEMP_ROW',['../class_user.html#a6638b80041e0c6cc1229e4836e70e968',1,'User']]]
];
