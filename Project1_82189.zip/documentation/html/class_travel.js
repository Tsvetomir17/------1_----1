var class_travel =
[
    [ "Travel", "class_travel.html#acc3bc73b916e588699d18ba7d4bb25c2", null ],
    [ "Travel", "class_travel.html#a3e9aed48a34eb599a80eab350c9813ca", null ],
    [ "~Travel", "class_travel.html#a31a118dac93f7ef4ede97e23f850680f", null ],
    [ "checkPhotosValidation", "class_travel.html#a6b95e470b4fb9b16d6390a7fe8be5515", null ],
    [ "copy", "class_travel.html#a6469b9a49379b4cef8124cc55ad1a783", null ],
    [ "deallocate", "class_travel.html#a05cbe75d3d60e28d4b95ffdd5a94d3b7", null ],
    [ "operator=", "class_travel.html#a7f3f19a45e56c4b03f0507f6452f4770", null ],
    [ "operator<<", "class_travel.html#aac8c753e9b3a58ae9ef2507db70d73dd", null ],
    [ "operator>>", "class_travel.html#abd87146f1203c6a1bd70bbf67afb627c", null ],
    [ "comment", "class_travel.html#a64d84152797d2aec95bfba5fc4869c50", null ],
    [ "destination", "class_travel.html#aff123d5a1e8f6a16cec2d77600b86fbd", null ],
    [ "grade", "class_travel.html#ad6bc17934c328bd03279237a5d3d6ebc", null ],
    [ "photos", "class_travel.html#a04bf365caaa5dcc68434e742766bd4b0", null ],
    [ "timePeriod", "class_travel.html#ab08e2b6ccef0a0e1546a678962d8fd5d", null ]
];