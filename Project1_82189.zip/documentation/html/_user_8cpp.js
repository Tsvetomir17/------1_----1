var _user_8cpp =
[
    [ "operator<<", "_user_8cpp.html#a4b94d005cfaf22d1536ee0b653a2b44b", null ],
    [ "operator>>", "_user_8cpp.html#a24f81f911c6acaee5721f6e0d49f527f", null ]
];