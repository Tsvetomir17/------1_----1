var files_dup =
[
    [ "Date.cpp", "_date_8cpp.html", "_date_8cpp" ],
    [ "Date.hpp", "_date_8hpp.html", [
      [ "Date", "class_date.html", "class_date" ]
    ] ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "menu.cpp", "menu_8cpp.html", null ],
    [ "menu.hpp", "menu_8hpp.html", [
      [ "Menu", "class_menu.html", "class_menu" ]
    ] ],
    [ "Travel.cpp", "_travel_8cpp.html", "_travel_8cpp" ],
    [ "Travel.hpp", "_travel_8hpp.html", [
      [ "Travel", "class_travel.html", "class_travel" ]
    ] ],
    [ "User.cpp", "_user_8cpp.html", "_user_8cpp" ],
    [ "User.hpp", "_user_8hpp.html", [
      [ "User", "class_user.html", "class_user" ]
    ] ]
];