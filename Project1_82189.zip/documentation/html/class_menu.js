var class_menu =
[
    [ "Menu", "class_menu.html#ad466dd83355124a6ed958430450bfe94", null ],
    [ "checkInputChoice", "class_menu.html#a0d54dac40ab7283f3517c99e0b25d1bf", null ],
    [ "checkInputChoiceAfterLogIn", "class_menu.html#a791c8504dfa7b512a1d72c57deab7965", null ],
    [ "getRating", "class_menu.html#af82b0adedab6c3f715312d84c4e42040", null ],
    [ "menuFirst", "class_menu.html#ab84f14ed41c3438aed04a085e26df141", null ],
    [ "menuSecond", "class_menu.html#a3f7b96a82a2d50b8b6bee27b35dd58ac", null ],
    [ "printMenuFirst", "class_menu.html#ae07398a93d97807e23950ac6977404aa", null ],
    [ "printMenuSecond", "class_menu.html#ab9cc07b4bc8ba162084c11f79d9c53b9", null ],
    [ "choice", "class_menu.html#ad5152b40c2819510f9e74600f4b510ad", null ],
    [ "choiceAfterLogIn", "class_menu.html#aa121983b063e5689482b800648ac2eff", null ],
    [ "fileName", "class_menu.html#a72a067659904a0ade3e0ba2c4bddf607", null ],
    [ "id", "class_menu.html#aac3b853a64aca7ef6e70fceae8c126be", null ],
    [ "username", "class_menu.html#acce4ed016501b2869706776e4f794b0b", null ]
];