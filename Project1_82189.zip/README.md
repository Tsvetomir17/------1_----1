Тема 1: Дневник на пътешественика

https://github.com/Tsvetomir17/Project1